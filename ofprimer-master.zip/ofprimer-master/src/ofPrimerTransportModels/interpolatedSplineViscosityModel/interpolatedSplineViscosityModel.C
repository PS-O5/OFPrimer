/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "interpolatedSplineViscosityModel.H"
#include "addToRunTimeSelectionTable.H"
#include "surfaceFields.H"
#include "interpolateSplineXY.H"
#include "mathematicalConstants.H"
#include "Tuple2.H"
#include "IFstream.H"
#include "volFields.H"
#include "fvcGrad.H"
#include "zeroGradientFvPatchFields.H"
#include "csvTableReader.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{
namespace viscosityModels
{
    defineTypeNameAndDebug(interpolatedSplineViscosityModel, 0);

    addToRunTimeSelectionTable
    (
        viscosityModel,
        interpolatedSplineViscosityModel,
        dictionary
    );


// * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * * //


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

interpolatedSplineViscosityModel::interpolatedSplineViscosityModel
(
    const word& name,
    const dictionary& viscosityProperties,
    const volVectorField& U,
    const surfaceScalarField& phi
)
:
    viscosityModel(name, viscosityProperties, U, phi),
    modelDict_(viscosityProperties.subDict(typeName + "Coeffs")),
    dataFileName_(modelDict_.lookup("dataFileName")),
    rheologyTableX_(),
    rheologyTableY_(),
    nuPtr_
    (
        new volScalarField
        ( 
            IOobject
            (
                name,
                U_.time().timeName(),
                U_.mesh(),
                IOobject::NO_READ,
                IOobject::AUTO_WRITE // IOobject::NO_WRITE usually!
            ), 
            U.mesh(), 
            dimensionedScalar("nu_", dimViscosity, 1e-06), 
            "zeroGradient"
        )
    )
{
    loadViscosityTable();
}


// * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * * //

bool interpolatedSplineViscosityModel::read
(
    const dictionary& viscosityProperties
)
{
    viscosityModel::read(viscosityProperties);

    modelDict_ = viscosityProperties.subDict(typeName + "Coeffs");
    modelDict_.lookup("dataFileName") >> dataFileName_;

    // Parse viscosity data table.
    loadViscosityTable();   

    return true;
}

void interpolatedSplineViscosityModel::loadViscosityTable()
{
    csvTableReader<scalar>  reader(modelDict_);

    List<Tuple2<scalar, scalar>> data; 
    reader(dataFileName_, data);  

    // Resize to experimental data 
    rheologyTableX_.resize(data.size());
    rheologyTableY_.resize(data.size());

    forAll(data, lineI)
    {
        const auto& dataTuple = data[lineI]; 
        rheologyTableX_[lineI] = dataTuple.first();
        rheologyTableY_[lineI] = dataTuple.second();
    }
}

void interpolatedSplineViscosityModel::correct()
{
    // Interpolate kinematic viscosity in each cell from tabular data.
    volScalarField& nu = nuPtr_.ref();
    const volScalarField cellStrainRate = strainRate();
    forAll(cellStrainRate, cellI)
    {
        nu[cellI] = interpolateSplineXY
        (
            cellStrainRate[cellI], 
            rheologyTableX_,
            rheologyTableY_
        );  
    }
    nu.correctBoundaryConditions(); 
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace viscosityModels
} // End namespace Foam

// ************************************************************************* //
