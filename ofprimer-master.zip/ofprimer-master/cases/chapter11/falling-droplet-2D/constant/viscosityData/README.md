Diagram data are taken from  

Anand, M., & Rajagopal, K. R. (2004). A shear-thinning viscoelastic fluid model for describing the flow of blood. International Journal of Cardiovascular Medicine and Science, 4(2), 59-68.

Figure 2, experimental data points are scanned. 
